# sitePac
site que teremos que terminar de desenvolver até o final do semestre

Ideias até agora (05/03/2020)

  VANT
  
  1 - Onde é aplicado?
  
    * agricultura
    * fotos panorâmicas
    * tele entrega
    * uso pessoal
    
  2 - Drones
  
    * Avião remoto
    * Projetos ( feitos e projetos futuros)
    * Avião tripulado
    
    3 - Conceitos básicos
    
      * o que é?
      * arduino, como funciona?
      
    4 - Aplicação na guerra
    
      * guerra fria e vietnã
      * x1-2 FireBee
      
     5 - Projeto aluno sala: 
     
      * qual o projeto?
      * qual a aplicação?
      * como se iniciou?
